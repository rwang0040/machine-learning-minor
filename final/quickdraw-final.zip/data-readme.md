# Quick, Draw! 飞机与直升机分类数据

`train.csv` 包含 4,000 张 28×28 灰度简笔画，飞机与直升机各 2,000 张。每行一张图，列顺序如下。

| 列 | 含义 |
|---|---|
| `sample_id` | 课程样本编号，用于核对行对应 |
| `p000` 至 `p783` | 按从上到下、从左到右的顺序展开的像素，整数值范围为 0–255 |
| `label` | 0 为飞机（airplane），1 为直升机（helicopter） |

标签对应玩家收到的绘图提示。使用 NumPy 把一行像素还原为 `(28, 28)`，即可查看原图。

数据由 Google 提供，来自 Quick, Draw! 官方 NumPy 点阵文件。课程对子集进行了筛选、抽样和重新编号，以 CSV 格式发放。 [官方数据来源](https://github.com/googlecreativelab/quickdraw-dataset#numpy-bitmaps-npy) · [CC BY 4.0 许可](https://creativecommons.org/licenses/by/4.0/)
